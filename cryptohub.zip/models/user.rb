class Model < ActiveRecord::Base
  
end
